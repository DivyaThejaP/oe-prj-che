<!-- PULL REQUEST TEMPLATE -->
<!-- (Update "[ ]" to "[x]" to check a box) -->

## Pull Request Checklist

- [ ] Read our contributing guidelines: https://github.com/progress/Spark-Server/blob/master/CONTRIBUTING.md#contribute.

[Describe the impact of the changes here. Please include issue # if applicable.]

<!--
Thank you for your contribution!
-->